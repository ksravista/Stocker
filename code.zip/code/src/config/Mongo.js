

const MongoClient = require('mongodb').MongoClient;


export default MongoClient;